package com.example.projekapsss.data.repository

import androidx.lifecycle.LiveData
import com.example.projekapsss.data.database.Task
import com.example.projekapsss.data.database.TaskDao

/**
 * TaskRepository: Repositori untuk mengelola data tugas.
 * Menyediakan metode untuk mengakses data dari sumber lokal (Room).
 */
class TaskRepository(private val taskDao: TaskDao) {

    val allTasks: LiveData<List<Task>> = taskDao.getAllTasks()

    suspend fun insert(task: Task) {
        taskDao.insertTask(task)
    }

    suspend fun update(task: Task) {
        taskDao.updateTask(task)
    }

    suspend fun delete(task: Task) {
        taskDao.deleteTask(task)
    }
}
