package com.example.projekapsss.ui.add

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.projekapsss.R
import com.example.projekapsss.model.Task
import com.example.projekapsss.viewmodel.TaskViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTaskActivity : AppCompatActivity() {

    private lateinit var etTaskName: EditText
    private lateinit var etTaskDescription: EditText
    private lateinit var etTaskDate: EditText
    private lateinit var btnAdd: Button
    private val calendar = Calendar.getInstance()
    private lateinit var taskViewModel: TaskViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)

        etTaskName = findViewById(R.id.et_task_name)
        etTaskDescription = findViewById(R.id.et_task_description)
        etTaskDate = findViewById(R.id.et_task_date)
        btnAdd = findViewById(R.id.btn_add)

        taskViewModel = ViewModelProvider(this).get(TaskViewModel::class.java)

        etTaskDate.setOnClickListener {
            showDatePicker()
        }

        btnAdd.setOnClickListener {
            addTask()
        }
    }

    private fun showDatePicker() {
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDateInView()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    private fun updateDateInView() {
        val myFormat = "dd/MM/yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.getDefault())
        etTaskDate.setText(sdf.format(calendar.time))
    }

    private fun addTask() {
        val taskName = etTaskName.text.toString()
        val taskDescription = etTaskDescription.text.toString()
        val taskDate = etTaskDate.text.toString()

        if (taskName.isNotEmpty()) {
            val task = Task(title = taskName, description = taskDescription, date = taskDate)
            taskViewModel.insert(task)
            finish()
        }
    }
}