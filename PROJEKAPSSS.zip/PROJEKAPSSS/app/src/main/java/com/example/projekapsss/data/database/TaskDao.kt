package com.example.projekapsss.data.database

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * TaskDao: Data Access Object untuk entitas Task.
 * Menyediakan metode untuk berinteraksi dengan tabel 'tasks' di database.
 */
@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks ORDER BY date DESC")
    fun getAllTasks(): LiveData<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)
}
