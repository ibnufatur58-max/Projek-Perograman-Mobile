package com.example.projekapsss.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.projekapsss.model.Task

@Dao
interface TaskDao {

    @Insert
    suspend fun insertTask(task: Task)

    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun getAllTasks(): LiveData<List<Task>>

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)

    // Query untuk Statistik
    @Query("SELECT COUNT(id) FROM tasks")
    fun getTotalTaskCount(): LiveData<Int>

    @Query("SELECT COUNT(id) FROM tasks WHERE isCompleted = 1")
    fun getCompletedTaskCount(): LiveData<Int>
}