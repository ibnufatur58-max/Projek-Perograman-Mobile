package com.example.projekapsss.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projekapsss.R
import com.example.projekapsss.databinding.ActivityHomeBinding
import com.example.projekapsss.ui.add.AddTaskActivity
import com.example.projekapsss.ui.profile.ProfileActivity
import com.example.projekapsss.viewmodel.TaskViewModel

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val taskViewModel: TaskViewModel by viewModels()
    private lateinit var taskAdapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        observeTasks()

        binding.fabAddTask.setOnClickListener {
            openAddTaskActivity()
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Sudah di Home, tidak perlu aksi
                    true
                }
                R.id.navigation_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }

    private fun openAddTaskActivity() {
        val intent = Intent(this, AddTaskActivity::class.java)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.home_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_add_task -> {
                openAddTaskActivity()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupRecyclerView() {
        taskAdapter = TaskAdapter(
            mutableListOf(),
            { task, isChecked -> // Aksi untuk update (checkbox)
                taskViewModel.update(task.copy(isCompleted = isChecked))
            },
            { task -> // Aksi untuk hapus (ikon sampah)
                taskViewModel.delete(task)
            }
        )
        binding.rvTasks.apply {
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = taskAdapter
        }
    }

    private fun observeTasks() {
        taskViewModel.allTasks.observe(this) {
            taskAdapter.setTasks(it)
        }
    }
}
