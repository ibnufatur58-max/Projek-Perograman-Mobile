package com.example.projekapsss.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.projekapsss.databinding.ActivityLoginBinding
import com.example.projekapsss.ui.home.HomeActivity
import com.example.projekapsss.ui.register.RegisterActivity

/**
 * LoginActivity: Halaman untuk pengguna masuk ke aplikasi.
 * Memvalidasi input email dan password.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Menggunakan View Binding untuk mengakses layout
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Listener untuk tombol login
        binding.btnLogin.setOnClickListener {
            handleLogin()
        }

        // Listener untuk teks 'CREATE AKUN'
        binding.tvCreateAccount.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    /**
     * Menangani logika saat tombol login ditekan.
     */
    private fun handleLogin() {
        // Mengambil teks dari EditText
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        // Validasi input tidak boleh kosong
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email tidak boleh kosong"
            return
        } else {
            binding.tilEmail.error = null
        }

        if (password.isEmpty()) {
            binding.tilPassword.error = "Password tidak boleh kosong"
            return
        } else {
            binding.tilPassword.error = null
        }

        // Jika validasi berhasil, pindah ke HomeActivity
        // NOTE: Logika otentikasi (misal: cek ke database/API) akan ditempatkan di sini.
        // Untuk sekarang, kita langsung navigasi.
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish() // Menutup LoginActivity agar tidak bisa kembali dengan tombol back
    }
}
