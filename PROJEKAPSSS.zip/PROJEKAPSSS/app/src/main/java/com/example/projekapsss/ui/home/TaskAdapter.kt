package com.example.projekapsss.ui.home

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.projekapsss.model.Task
import com.example.projekapsss.databinding.ItemTaskBinding

class TaskAdapter(
    private val tasks: MutableList<Task>,
    private val onTaskChecked: (Task, Boolean) -> Unit,
    private val onTaskDeleted: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(tasks[position])
    }

    override fun getItemCount(): Int = tasks.size

    fun setTasks(newTasks: List<Task>) {
        tasks.clear()
        tasks.addAll(newTasks)
        notifyDataSetChanged()
    }

    inner class TaskViewHolder(private val binding: ItemTaskBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(task: Task) {
            binding.tvTaskName.text = task.title
            binding.tvTaskDate.text = task.date // <-- BARIS INI DITAMBAHKAN
            binding.cbStatus.isChecked = task.isCompleted

            updateTaskAppearance(task.isCompleted)

            binding.cbStatus.setOnCheckedChangeListener { _, isChecked ->
                onTaskChecked.invoke(task, isChecked)
                updateTaskAppearance(isChecked)
            }

            binding.ivDelete.setOnClickListener {
                onTaskDeleted.invoke(task)
            }
        }

        private fun updateTaskAppearance(isCompleted: Boolean) {
            if (isCompleted) {
                binding.tvTaskName.paintFlags = binding.tvTaskName.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                binding.tvTaskName.paintFlags = binding.tvTaskName.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
        }
    }
}
