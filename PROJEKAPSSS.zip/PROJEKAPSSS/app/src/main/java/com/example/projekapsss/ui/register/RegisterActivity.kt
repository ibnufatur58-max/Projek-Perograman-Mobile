package com.example.projekapsss.ui.register

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.projekapsss.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {
            // Untuk saat ini, kita hanya akan menampilkan pesan dan kembali
            // Di masa depan, di sinilah logika untuk menyimpan user baru akan ditambahkan
            Toast.makeText(this, "Fitur registrasi sedang dikembangkan", Toast.LENGTH_SHORT).show()
            finish() // Kembali ke halaman sebelumnya (LoginActivity)
        }
    }
}
