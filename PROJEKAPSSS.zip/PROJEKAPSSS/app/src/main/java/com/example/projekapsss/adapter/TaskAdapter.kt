package com.example.projekapsss.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.projekapsss.R
import com.example.projekapsss.model.Task

class TaskAdapter(
    private var tasks: MutableList<Task>,
    private val onTaskCheckedChanged: (Task, Boolean) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.bind(task)
    }

    override fun getItemCount(): Int = tasks.size

    fun setTasks(tasks: List<Task>) {
        this.tasks.clear()
        this.tasks.addAll(tasks)
        notifyDataSetChanged()
    }

    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cbStatus: CheckBox = itemView.findViewById(R.id.cb_status)
        private val tvTaskName: TextView = itemView.findViewById(R.id.tv_task_name)

        fun bind(task: Task) {
            tvTaskName.text = task.title // Ganti dari name ke title
            cbStatus.isChecked = task.isCompleted

            cbStatus.setOnCheckedChangeListener { _, isChecked ->
                onTaskCheckedChanged(task, isChecked)
            }
        }
    }
}