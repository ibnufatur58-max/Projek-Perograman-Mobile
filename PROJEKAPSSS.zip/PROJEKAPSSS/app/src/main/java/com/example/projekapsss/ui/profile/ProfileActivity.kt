package com.example.projekapsss.ui.profile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.projekapsss.R
import com.example.projekapsss.ui.login.LoginActivity
import com.example.projekapsss.viewmodel.TaskViewModel

class ProfileActivity : AppCompatActivity() {

    private lateinit var flProfileImageContainer: FrameLayout
    private lateinit var ivProfileIcon: ImageView
    private lateinit var tvUsername: TextView
    private lateinit var tvEmail: TextView
    private lateinit var btnLogout: Button
    private lateinit var tvTotalTasks: TextView
    private lateinit var tvCompletedTasks: TextView
    private lateinit var pbCompletionRate: ProgressBar

    private val taskViewModel: TaskViewModel by viewModels()

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val imageUri: Uri? = result.data?.data
            ivProfileIcon.setImageURI(imageUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        initViews()
        setupListeners()
        observeViewModel()

        // Set dummy data
        tvUsername.text = "John Doe"
        tvEmail.text = "john.doe@example.com"
    }

    private fun initViews() {
        flProfileImageContainer = findViewById(R.id.fl_profile_image_container)
        ivProfileIcon = findViewById(R.id.iv_profile_icon)
        tvUsername = findViewById(R.id.tv_username)
        tvEmail = findViewById(R.id.tv_email)
        btnLogout = findViewById(R.id.btn_logout)
        tvTotalTasks = findViewById(R.id.tv_total_tasks)
        tvCompletedTasks = findViewById(R.id.tv_completed_tasks)
        pbCompletionRate = findViewById(R.id.pb_completion_rate)
    }

    private fun setupListeners() {
        flProfileImageContainer.setOnClickListener {
            openGallery()
        }
        btnLogout.setOnClickListener {
            logoutUser()
        }
    }

    private fun observeViewModel() {
        taskViewModel.totalTaskCount.observe(this) { total ->
            tvTotalTasks.text = "Total Tugas: ${total ?: 0}"
            updateProgressBar()
        }

        taskViewModel.completedTaskCount.observe(this) { completed ->
            tvCompletedTasks.text = "Tugas Selesai: ${completed ?: 0}"
            updateProgressBar()
        }
    }

    private fun updateProgressBar() {
        val total = taskViewModel.totalTaskCount.value ?: 0
        val completed = taskViewModel.completedTaskCount.value ?: 0

        if (total > 0) {
            val progress = (completed * 100) / total
            pbCompletionRate.progress = progress
        } else {
            pbCompletionRate.progress = 0
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        pickImageLauncher.launch(intent)
    }

    private fun logoutUser() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
